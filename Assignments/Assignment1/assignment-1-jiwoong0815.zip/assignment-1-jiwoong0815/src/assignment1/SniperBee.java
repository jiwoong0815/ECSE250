package assignment1;

import java.util.Arrays;

public class SniperBee extends HoneyBee{
    private int attackDamage;
    private int piercingPower;
    public static int BASE_HEALTH;
    public static int BASE_COST;

    public SniperBee(Tile position, int attackDamage, int piercingPower){
        super(position,BASE_HEALTH,BASE_COST);
        this.attackDamage = attackDamage;
        this.piercingPower = piercingPower;

    }

    private boolean aimingstatus = false;

    @Override
    public boolean takeAction() {
        if (!this.getPosition().isOnThePath()) return false;
        boolean returnbool = false;
        if (!aimingstatus) {
            aimingstatus = true;
            return false;
        }
        Tile aim = this.getPosition();
        while(aim.isNest() == false && aim.getNumOfHornets() == 0 && aim.isOnThePath()){
            aim = aim.towardTheNest();
//            System.out.println(aim.getNumOfHornets());
//            System.out.println(aim.getHornet());
//            System.out.println((aim));
        }

//        System.out.println(Arrays.toString(aim.getHornets()));
        if(aim.getNumOfHornets() == 0){
            return false;
        }
        for (int i = 0 ; i < piercingPower -1 ; i++){
            aim.getHornets()[i].takeDamage(attackDamage);
            returnbool = true;
        }
        aimingstatus = false;
        return returnbool;
    }

}
