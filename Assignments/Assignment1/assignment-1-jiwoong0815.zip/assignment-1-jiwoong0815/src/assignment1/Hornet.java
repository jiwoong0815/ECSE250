package assignment1;

public class Hornet extends Insect{

    private int attack_damage;
    public static int BASE_FIRE_DMG;
    private boolean isQueen = false;
    private static int queensTotal = 0;


    public Hornet(Tile position, int hp, int attack_damage){
        super(position,hp);
        this.attack_damage = attack_damage;
        position.addInsect(this);
    }

    private Boolean queenFirstTurns = true;

    public boolean takeAction() {
        boolean returnbool = false;
        if (this.getPosition().isOnFire()) {
            this.takeDamage(BASE_FIRE_DMG);
        }
        if (this.getPosition().getBee() != null) {
            this.getPosition().getBee().takeDamage(this.attack_damage);
            returnbool = true;
        } else if (this.getPosition().isHive() && this.getPosition().getBee() == null) {
            returnbool = false;
        } else if (this.getPosition().getBee() == null) {
            Tile tempLocation = this.getPosition();
            this.getPosition().removeInsect(this);
            this.setPosition(tempLocation.towardTheHive());
            returnbool = true;
        }

        if(queenFirstTurns && this.isQueen){
            queenFirstTurns = false;
            takeAction();
        }
            return returnbool;
    }
    @Override
    public boolean equals(Object object){
        if((object instanceof Hornet) &&( ((Hornet)object).getPosition() == this.getPosition() )&& (((Hornet)object).getHealth() == this.getHealth()) && (((Hornet)object).attack_damage == this.attack_damage)){
            return true;
        }
        return false;
    }

    public boolean isTheQueen(){
        return this.isQueen;
    }

    public void promote(){
        this.isQueen = true;
    }

}
